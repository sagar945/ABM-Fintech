var SWSLocObj = {
  vdvdv_ENABLED: 'enabled',
  vdvdv_MANDATORY: 'N',
  fbdfb_ENABLED: 'enabled',
  fbdfb_MANDATORY: 'N',
};
