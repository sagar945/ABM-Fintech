<? xml version = "1.0" encoding = "UTF-8" ?>
  <group_details>
    <multi_tab_menu>N</multi_tab_menu>
    <page_list>
      <page_details>
        <type_of_page>INITIAL</type_of_page>
        <page_name>sws_crit.jsp</page_name>
      </page_details>
      <page_details>
        <type_of_page>DETAILS</type_of_page>
        <page_name>sws_det.jsp</page_name>
      </page_details>
      <page_details>
        <type_of_page>RESULT</type_of_page>
        <page_name>sws_res.jsp</page_name>
      </page_details>
    </page_list>
    <invocation_list>
      <invocation_details>
        <action_code>GETDATA</action_code>
        <function_code>A</function_code>
        <invocation_name>sws_Crit_mn001.scr</invocation_name>
      </invocation_details>
      <invocation_details>
        <action_code>SUBMIT</action_code>
        <function_code>NA</function_code>
        <invocation_name>sws_submit.scr</invocation_name>
      </invocation_details>
      <invocation_details>
        <action_code>VALIDATE</action_code>
        <function_code>swsValidate.scr</function_code>
        <invocation_name></invocation_name>
      </invocation_details>
    </invocation_list>
    <tab_details_list>
      <header_fields />
    </tab_details_list>
    <multirec_list />
    <field_list>
      <field>
        <name>Account Number</name>
        <datatype>String</datatype>
        <mr_field>N</mr_field>
        <group_field>Y</group_field>
      </field>

      , <field>
        <name>Branch Name</name>
        <datatype>String</datatype>
        <mr_field>N</mr_field>
        <group_field>Y</group_field>
      </field>

      , <field>
        <name>Account Name</name>
        <datatype>String</datatype>
        <mr_field>N</mr_field>
        <group_field>Y</group_field>
      </field>


    </field_list>
    <module_name />
  </group_details>

