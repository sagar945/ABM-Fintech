<?php session_start();

    $servername='localhost';
    $username='root';
    $password='';
    $dbname = "sks_project";
     // Establish a database connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>