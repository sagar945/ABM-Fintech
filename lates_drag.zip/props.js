var SWSLocObj = {
};
